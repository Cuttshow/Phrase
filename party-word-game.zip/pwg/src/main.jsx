import React from "react";
import { createRoot } from "react-dom/client";
import PartyWordGame from "./PartyWordGame.jsx";
import "./index.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <PartyWordGame />
  </React.StrictMode>
);
