import React, { useState, useEffect, useRef, useLayoutEffect, useCallback } from "react";

/* ------------------------------------------------------------------ */
/*  PALETTE                                                            */
/* ------------------------------------------------------------------ */
const C = {
  ink: "#150E28",
  ink2: "#1F1436",
  plum: "#2E1B52",
  magenta: "#FF3D7F",
  amber: "#FFC145",
  mint: "#3DDC97",
  cream: "#FFF4E6",
  danger: "#D91036",
  dim: "rgba(255,244,230,0.55)",
  dimmer: "rgba(255,244,230,0.28)",
};

/* ------------------------------------------------------------------ */
/*  WORD DATA                                                          */
/*  groups: [label, isAlcoholic, [...words]]                           */
/* ------------------------------------------------------------------ */
const DECKS = {
  beverages: {
    label: "Beverages",
    blurb: "300 drinks",
    groups: [
      ["Coffee & tea", false, ["Coffee","Espresso","Latte","Cappuccino","Iced coffee","Cold brew","Mocha","Macchiato","Americano","Green tea","Iced tea","Chai","Herbal tea","Sweet tea","Chamomile tea","Flat white","Frappuccino","Drip coffee","Instant coffee","Decaf","Pumpkin spice latte","Irish coffee","Turkish coffee","French press","Affogato","Matcha","Black tea","Earl Grey","Oolong tea","Bubble tea","Thai iced tea","Arnold Palmer","Peppermint tea","Nitro cold brew","Cortado"]],
      ["Soft drinks", false, ["Soda","Coca-Cola","Pepsi","Root beer","Ginger ale","Sprite","Dr Pepper","Mountain Dew","Cream soda","Orange soda","Diet Coke","Club soda","Tonic water","Seltzer","Cola","Fanta","7 Up","Cherry Coke","Shirley Temple","Perrier","LaCroix","Ginger beer","Sarsaparilla","Fresca","San Pellegrino","Crush","Vanilla Coke","RC Cola","Jarritos","Fountain drink"]],
      ["Juice", false, ["Orange juice","Apple juice","Grape juice","Cranberry juice","Lemonade","Pink lemonade","Limeade","Tomato juice","Pineapple juice","Fruit punch","Grapefruit juice","Apple cider","Mango juice","Carrot juice","Prune juice","V8","Green juice","Pomegranate juice","Peach nectar","Watermelon juice","Guava juice","Agua fresca","Fresh squeezed juice","Celery juice"]],
      ["Water", false, ["Water","Sparkling water","Ice water","Bottled water","Tap water","Coconut water","Mineral water","Lemon water"]],
      ["Milk & blended", false, ["Milk","Chocolate milk","Strawberry milk","Milkshake","Eggnog","Hot chocolate","Smoothie","Malt","Buttermilk","Almond milk","Oat milk","Soy milk","Whole milk","Skim milk","Condensed milk","Evaporated milk","Goat milk","Kefir","Lassi","Milk tea","Egg cream","Root beer float","Coconut milk"]],
      ["Sports & energy", false, ["Gatorade","Energy drink","Red Bull","Sports drink","Protein shake","Kombucha","Slushie","Horchata","Powerade","Kool-Aid","Capri Sun","Ovaltine","Monster"]],
      ["Beer & wine", true, ["Beer","Draft beer","IPA","Lager","Stout","Guinness","Light beer","Craft beer","Wine","Red wine","White wine","Champagne","Rosé","Sangria","Mimosa","Boxed wine","Pilsner","Ale","Pale ale","Porter","Wheat beer","Hard cider","Corona","Budweiser","Heineken","Michelada","Shandy","Merlot","Chardonnay","Cabernet","Pinot noir","Prosecco","Moscato","Mulled wine","Sake","Mead"]],
      ["Cocktails & spirits", true, ["Margarita","Martini","Mojito","Bloody Mary","Piña colada","Whiskey","Vodka","Tequila","Rum","Gin and tonic","Screwdriver","Long Island iced tea","Old Fashioned","Daiquiri","Shot","Moonshine","Cosmopolitan","Manhattan","Moscow mule","Mint julep","White Russian","Mai tai","Tequila sunrise","Whiskey sour","Aperol spritz","Negroni","Bourbon","Scotch","Brandy","Absinthe","Hot toddy"]],
      ["Beer brands", true, ["Coors Light","Bud Light","Miller Lite","Modelo","Stella Artois","Pabst Blue Ribbon","Sam Adams","Blue Moon","Sierra Nevada","Dos Equis","Tecate","Yuengling","Natural Light","Miller High Life","Red Stripe","Busch Light"]],
      ["Beer styles", true, ["Hefeweizen","Sour beer","Amber ale","Brown ale","Saison","Bock","Hazy IPA","Oktoberfest","Malt liquor","Non-alcoholic beer"]],
      ["Wine varietals", true, ["Sauvignon blanc","Pinot grigio","Riesling","Zinfandel","White zinfandel","Malbec","Shiraz","Chianti","Bordeaux","Burgundy","Port","Sherry","Vermouth","Cava","Ice wine","Dessert wine","House wine","Sparkling wine"]],
      ["Spirits labels", true, ["Jack Daniel's","Jim Beam","Jameson","Johnnie Walker","Grey Goose","Smirnoff","Absolut","Tito's","Bacardi","Captain Morgan","Malibu Rum","Patrón","Jose Cuervo","Don Julio","Hennessy","Crown Royal","Maker's Mark","Wild Turkey","Fireball","Tanqueray","Bombay Sapphire","Everclear"]],
      ["Spirit types", true, ["Mezcal","Cognac","Rye whiskey","Single malt","Soju","Ouzo","Grappa"]],
      ["Liqueurs", true, ["Baileys","Kahlúa","Triple sec","Amaretto","Jägermeister","Schnapps","Limoncello","Campari","Southern Comfort","Grand Marnier"]],
      ["More cocktails", true, ["Gimlet","Tom Collins","Rum and Coke","Jack and Coke","Vodka soda","Sex on the Beach","Paloma","Espresso martini","Dirty martini","French 75","Bellini"]],
      ["Ready-to-drink", true, ["White Claw","Hard seltzer","Twisted Tea","Mike's Hard Lemonade","Franzia","Wine cooler"]],
    ],
  },
  food: {
    label: "Food",
    blurb: "500 dishes & ingredients",
    groups: [
      ["American classics", false, ["Meatloaf","Mac and cheese","Fried chicken","Pot roast","Chicken pot pie","Casserole","Sloppy joe","Corn dog","Chili","Clam chowder","Lobster roll","Buffalo wings","Deviled eggs","Potato salad","Coleslaw","Baked beans","Corn on the cob","Thanksgiving turkey","Stuffing","Cranberry sauce","Green bean casserole","Mashed potatoes","Gravy","Tater tots","Onion rings","Nachos","Jambalaya","Shrimp and grits"]],
      ["Breakfast", false, ["Pancakes","Waffles","French toast","Bacon","Scrambled eggs","Fried egg","Omelette","Eggs Benedict","Hash browns","Sausage links","Oatmeal","Cereal","Granola","Bagel and cream cheese","Breakfast burrito","Biscuits and gravy","Grits","Yogurt parfait","Cinnamon roll","Doughnut","Toast","Corned beef hash"]],
      ["Sandwiches & burgers", false, ["Cheeseburger","Hamburger","Hot dog","BLT","Grilled cheese","Club sandwich","Reuben","Philly cheesesteak","Tuna salad sandwich","Peanut butter and jelly","Meatball sub","Chicken sandwich","Patty melt","Slider","Muffuletta","Po' boy","Egg salad sandwich","Panini"]],
      ["Southern & BBQ", false, ["Barbecue ribs","Pulled pork","Brisket","Smoked sausage","Cornbread","Collard greens","Black-eyed peas","Hush puppies","Fried okra","Chicken and waffles","Catfish","Gumbo","Red beans and rice","Biscuits","Country ham","Chitlins","Burnt ends","Pimento cheese","Banana pudding","Peach cobbler","Sweet potato pie","Boiled peanuts"]],
      ["Fast food & junk", false, ["French fries","Chicken nuggets","Drive-thru","Happy Meal","Big Mac","Whopper","Curly fries","Chili cheese fries","Soft serve","Frozen yogurt","Funnel cake","Cotton candy","Chili dog","Taco Bell","McDonald's","Food truck","All-you-can-eat buffet","Leftovers"]],
      ["Italian", false, ["Pizza","Spaghetti","Lasagna","Fettuccine Alfredo","Ravioli","Gnocchi","Risotto","Meatballs","Chicken parmesan","Eggplant parmesan","Carbonara","Pesto","Marinara","Bruschetta","Garlic bread","Caprese salad","Prosciutto","Calzone","Stromboli","Minestrone","Tiramisu","Cannoli","Gelato","Focaccia"]],
      ["Mexican & Latin", false, ["Taco","Burrito","Quesadilla","Enchilada","Tamale","Guacamole","Salsa","Chips and salsa","Fajitas","Churro","Elote","Carne asada","Carnitas","Al pastor","Chile relleno","Menudo","Pozole","Mole","Refried beans","Tortilla","Empanada","Ceviche","Arroz con pollo","Plantains"]],
      ["Chinese", false, ["Fried rice","Lo mein","Chow mein","Egg roll","Spring roll","Dumplings","Potstickers","General Tso's chicken","Orange chicken","Kung Pao chicken","Sweet and sour pork","Beef and broccoli","Wonton soup","Egg drop soup","Hot pot","Peking duck","Dim sum","Bao buns","Fortune cookie","Chop suey"]],
      ["Japanese", false, ["Sushi","Sashimi","California roll","Ramen","Udon","Soba","Tempura","Teriyaki chicken","Miso soup","Edamame","Gyoza","Yakitori","Katsu","Onigiri","Wasabi","Seaweed salad","Hibachi","Mochi"]],
      ["Southeast Asian", false, ["Pad Thai","Green curry","Red curry","Tom yum soup","Pho","Banh mi","Summer rolls","Satay","Nasi goreng","Laksa","Sticky rice","Mango sticky rice","Lumpia","Peanut sauce"]],
      ["Indian", false, ["Curry","Chicken tikka masala","Butter chicken","Naan","Samosa","Tandoori chicken","Biryani","Saag paneer","Dal","Chutney","Papadum","Roti","Vindaloo","Korma","Raita","Basmati rice"]],
      ["Middle Eastern & Mediterranean", false, ["Hummus","Falafel","Pita bread","Shawarma","Gyro","Kebab","Tzatziki","Tabbouleh","Baba ganoush","Stuffed grape leaves","Couscous","Baklava","Feta cheese","Greek salad","Spanakopita","Moussaka","Shakshuka","Halloumi"]],
      ["French", false, ["Croissant","Baguette","Quiche","Crêpes","French onion soup","Coq au vin","Beef bourguignon","Ratatouille","Escargot","Foie gras","Crème brûlée","Macaron","Éclair","Soufflé"]],
      ["German & Eastern European", false, ["Bratwurst","Schnitzel","Sauerkraut","Pretzel","Strudel","Pierogi","Borscht","Goulash","Stroganoff","Kielbasa","Blintz","Latke"]],
      ["Soups, stews & salads", false, ["Chicken noodle soup","Tomato soup","Split pea soup","Beef stew","Lentil soup","Caesar salad","Cobb salad","Garden salad","Waldorf salad","Chef salad","Fruit salad","Pasta salad","Egg salad","Chicken salad","Macaroni salad","Bisque","Broth","Wedge salad"]],
      ["Fruits", false, ["Apple","Banana","Orange","Strawberry","Blueberry","Raspberry","Blackberry","Grape","Watermelon","Cantaloupe","Honeydew","Pineapple","Mango","Peach","Pear","Plum","Cherry","Lemon","Lime","Grapefruit","Kiwi","Pomegranate","Coconut","Avocado","Fig","Apricot","Papaya","Cranberry"]],
      ["Vegetables", false, ["Broccoli","Carrot","Cauliflower","Spinach","Kale","Lettuce","Cabbage","Brussels sprouts","Asparagus","Zucchini","Cucumber","Tomato","Potato","Sweet potato","Onion","Garlic","Celery","Bell pepper","Jalapeño","Mushroom","Corn","Peas","Green beans","Eggplant","Beet","Radish","Artichoke","Butternut squash"]],
      ["Meats & seafood", false, ["Steak","Ribeye","Filet mignon","Ground beef","Pork chop","Ham","Turkey","Chicken breast","Chicken thigh","Lamb chop","Veal","Duck","Salmon","Tuna","Shrimp","Lobster","Crab","Scallops","Oysters","Clams","Mussels","Tilapia","Cod","Anchovy","Sardines","Beef jerky"]],
      ["Dairy & eggs", false, ["Cheddar cheese","Mozzarella","Parmesan","Swiss cheese","Blue cheese","Cream cheese","Cottage cheese","Butter","Sour cream","Heavy cream","Egg","Hard-boiled egg"]],
      ["Breads, grains & pasta", false, ["Sourdough","White bread","Whole wheat bread","Rye bread","Ciabatta","Brioche","Dinner roll","English muffin","Flatbread","Rice","Brown rice","Quinoa","Barley","Oats","Penne","Macaroni","Angel hair","Linguine","Orzo","Egg noodles"]],
      ["Spices & herbs", false, ["Salt","Black pepper","Cinnamon","Nutmeg","Paprika","Cumin","Chili powder","Curry powder","Turmeric","Ginger","Oregano","Basil","Thyme","Rosemary","Sage","Parsley","Cilantro","Dill","Mint","Bay leaf","Cayenne","Vanilla"]],
      ["Condiments & sauces", false, ["Ketchup","Mustard","Mayonnaise","Ranch dressing","Barbecue sauce","Hot sauce","Sriracha","Tabasco","Soy sauce","Teriyaki sauce","Worcestershire sauce","Relish","Pickles","Olive oil","Vinegar","Balsamic vinegar","Honey","Maple syrup","Jam","Peanut butter","Nutella","Tartar sauce"]],
      ["Desserts & baked goods", false, ["Apple pie","Pumpkin pie","Pecan pie","Key lime pie","Cheesecake","Chocolate cake","Carrot cake","Red velvet cake","Birthday cake","Cupcake","Brownie","Chocolate chip cookie","Sugar cookie","Oatmeal raisin cookie","Snickerdoodle","Ice cream","Sundae","Banana split","Ice cream cone","Ice cream sandwich","Popsicle","Pudding","Jell-O","Whipped cream","S'mores","Fudge","Muffin","Scone","Danish","Bread pudding"]],
      ["Candy & snacks", false, ["Chocolate bar","Gummy bears","Jelly beans","Candy corn","Lollipop","Marshmallow","Caramel","Potato chips","Popcorn","Trail mix","Peanuts","Crackers","Cheese puffs","Granola bar"]],
      ["Cooking & kitchen", false, ["Grill","Bake","Fry","Deep fry","Boil","Simmer","Roast","Sauté","Marinate","Recipe","Doggy bag","Potluck"]],
    ],
  },
  movies: {
    label: "Movies",
    blurb: "300 movies",
    groups: [
      ["Sci-fi & space", false, ["Star Wars","The Empire Strikes Back","Return of the Jedi","The Force Awakens","E.T.","Close Encounters","Blade Runner","The Matrix","The Terminator","Terminator 2","Back to the Future","Jurassic Park","Alien","Aliens","Avatar","Interstellar","Inception","Arrival","Gravity","The Martian","Independence Day","Men in Black","Star Trek","Dune"]],
      ["Fantasy & adventure", false, ["The Fellowship of the Ring","The Two Towers","The Return of the King","The Hobbit","Harry Potter","Raiders of the Lost Ark","Temple of Doom","The Last Crusade","The Princess Bride","The Wizard of Oz","Pirates of the Caribbean","The Goonies","Jumanji","Hook","The Mummy","Willy Wonka","Mary Poppins"]],
      ["Superheroes", false, ["The Dark Knight","Batman","Batman Begins","The Dark Knight Rises","Superman","Spider-Man","Spider-Man 2","Into the Spider-Verse","Iron Man","The Avengers","Infinity War","Endgame","Black Panther","Captain America","Thor","Guardians of the Galaxy","Deadpool","Wonder Woman","X-Men","Joker"]],
      ["Animated & family", false, ["Toy Story","The Lion King","Finding Nemo","Shrek","Frozen","Aladdin","Beauty and the Beast","The Little Mermaid","Snow White","Cinderella","Bambi","Pinocchio","Dumbo","Peter Pan","Sleeping Beauty","101 Dalmatians","The Jungle Book","Monsters, Inc.","Up","WALL-E","Ratatouille","Inside Out","Coco","Moana","Tangled","Despicable Me","The Incredibles","Cars","How to Train Your Dragon","Mulan","Zootopia","Encanto"]],
      ["Comedies", false, ["Ghostbusters","Airplane!","Caddyshack","Animal House","The Blues Brothers","Groundhog Day","Beverly Hills Cop","Coming to America","Trading Places","Big","Mrs. Doubtfire","Dumb and Dumber","Ace Ventura","The Mask","Happy Gilmore","Wayne's World","Austin Powers","Anchorman","Talladega Nights","Step Brothers","Superbad","Bridesmaids","The Hangover","Meet the Parents","Napoleon Dynamite","Elf","Office Space","School of Rock","Legally Blonde","Home Alone","Blazing Saddles","Young Frankenstein","The Naked Gun","The Big Lebowski","Christmas Vacation"]],
      ["Action & spy", false, ["Die Hard","Lethal Weapon","First Blood","Rambo","Predator","Top Gun","Top Gun: Maverick","Mission: Impossible","The Bourne Identity","Speed","The Rock","Bad Boys","True Lies","John Wick","Mad Max","Fury Road","The Fugitive","Air Force One","Gladiator","300","Taken","The Fast and the Furious","Kill Bill","Ocean's Eleven","Casino Royale","Skyfall","Jaws"]],
      ["Horror & scary", false, ["The Exorcist","Halloween","A Nightmare on Elm Street","Friday the 13th","Psycho","The Shining","Poltergeist","Carrie","It","The Ring","The Sixth Sense","Scream","The Blair Witch Project","Saw","The Conjuring","Get Out","Us","A Quiet Place","Night of the Living Dead","The Thing","The Silence of the Lambs","Rosemary's Baby","Beetlejuice","Gremlins"]],
      ["Crime & mob", false, ["The Godfather","The Godfather Part II","Goodfellas","Casino","Scarface","Pulp Fiction","Reservoir Dogs","The Departed","The Untouchables","The Usual Suspects","Se7en","Fight Club","American Gangster","Training Day","No Country for Old Men","Chinatown","Catch Me If You Can","The Wolf of Wall Street","Heat"]],
      ["Drama & Oscar night", false, ["The Shawshank Redemption","Forrest Gump","Schindler's List","Titanic","Rain Man","Good Will Hunting","A Beautiful Mind","Dead Poets Society","The Green Mile","Million Dollar Baby","American Beauty","The Social Network","12 Years a Slave","The Help","The Blind Side","La La Land","Moonlight","Whiplash","The Revenant","Cast Away","The Pursuit of Happyness","Oppenheimer","Everything Everywhere All at Once","Silver Linings Playbook"]],
      ["Romance & rom-coms", false, ["When Harry Met Sally","Sleepless in Seattle","You've Got Mail","Pretty Woman","Ghost","Dirty Dancing","The Notebook","10 Things I Hate About You","Clueless","The Princess Diaries","Crazy Rich Asians","50 First Dates","The Wedding Singer","Jerry Maguire","Grease"]],
      ["Sports movies", false, ["Rocky","Rocky IV","Creed","Raging Bull","Field of Dreams","The Sandlot","A League of Their Own","Major League","Hoosiers","Rudy","Remember the Titans","Space Jam","The Karate Kid","Moneyball","The Natural","Miracle"]],
      ["Golden age classics", false, ["Casablanca","Gone with the Wind","Citizen Kane","Singin' in the Rain","It's a Wonderful Life","Some Like It Hot","Sunset Boulevard","Rear Window","Vertigo","North by Northwest","12 Angry Men","To Kill a Mockingbird","The Ten Commandments","The Sound of Music","West Side Story","Breakfast at Tiffany's","Dr. Strangelove","Butch Cassidy and the Sundance Kid","Easy Rider","The Graduate","Cool Hand Luke"]],
      ["War movies", false, ["Saving Private Ryan","Apocalypse Now","Platoon","Full Metal Jacket","Black Hawk Down","The Deer Hunter","Patton","The Hurt Locker","American Sniper","Dunkirk","Inglourious Basterds","MASH"]],
      ["Teen & coming-of-age", false, ["The Breakfast Club","Ferris Bueller's Day Off","Sixteen Candles","Pretty in Pink","Stand by Me","The Outsiders","Dazed and Confused","American Pie","Juno","Lady Bird","Mean Girls","Risky Business","Fast Times at Ridgemont High","Footloose"]],
    ],
  },
  tv: {
    label: "TV Shows",
    blurb: "250 shows",
    groups: [
      ["Sitcom hall of fame", false, ["Cheers","Seinfeld","Friends","Frasier","Everybody Loves Raymond","Home Improvement","Full House","Family Matters","The Cosby Show","Roseanne","Married with Children","The Golden Girls","Will & Grace","The King of Queens","The Fresh Prince of Bel-Air","Martin","Family Ties","Murphy Brown","The Nanny","Two and a Half Men","The Big Bang Theory","How I Met Your Mother"]],
      ["Modern comedy", false, ["The Office","Parks and Recreation","30 Rock","Arrested Development","Community","Scrubs","Modern Family","Brooklyn Nine-Nine","New Girl","The Good Place","Veep","Curb Your Enthusiasm","It's Always Sunny in Philadelphia","Atlanta","Ted Lasso","Abbott Elementary","Only Murders in the Building","Malcolm in the Middle","Sex and the City"]],
      ["Prestige drama", false, ["The Sopranos","The Wire","Breaking Bad","Better Call Saul","Mad Men","The West Wing","The Shield","True Detective","Fargo","Ozark","Succession","Yellowstone","House of Cards","Dexter","Friday Night Lights","This Is Us","Lost","24","Euphoria","The Handmaid's Tale","Twin Peaks"]],
      ["Cops, crime & courtroom", false, ["Law & Order","Law & Order: SVU","CSI","CSI: Miami","NCIS","Criminal Minds","Monk","Psych","Columbo","Murder, She Wrote","NYPD Blue","Miami Vice","Magnum, P.I.","The Rockford Files","Cops","Unsolved Mysteries","L.A. Law","Suits","The Good Wife"]],
      ["Medical & first responders", false, ["ER","Grey's Anatomy","House","St. Elsewhere","Chicago Hope","The Good Doctor","Nurse Jackie","Chicago Fire","9-1-1","Rescue Me"]],
      ["Sci-fi, fantasy & horror", false, ["Star Trek: The Original Series","Star Trek: The Next Generation","The X-Files","The Twilight Zone","Battlestar Galactica","Buffy the Vampire Slayer","Supernatural","Charmed","Smallville","Heroes","Westworld","Game of Thrones","The Walking Dead","Stranger Things","The Mandalorian","The Boys","The Last of Us","Knight Rider","The Incredible Hulk","The Six Million Dollar Man","American Horror Story","True Blood","The Vampire Diaries"]],
      ["Animated", false, ["The Simpsons","South Park","Family Guy","King of the Hill","Futurama","Rick and Morty","Bob's Burgers","American Dad","Beavis and Butt-Head","The Flintstones","The Jetsons","Scooby-Doo","Looney Tunes","Tom and Jerry","SpongeBob SquarePants","Rugrats","Hey Arnold!","Avatar: The Last Airbender","Teenage Mutant Ninja Turtles","Transformers","DuckTales","Animaniacs","BoJack Horseman"]],
      ["Kids & Saturday morning", false, ["Sesame Street","Mister Rogers' Neighborhood","Barney & Friends","Blue's Clues","Dora the Explorer","Reading Rainbow","Bill Nye the Science Guy","Drake & Josh","iCarly","Hannah Montana","Wizards of Waverly Place","Power Rangers"]],
      ["Teen & young adult", false, ["Beverly Hills, 90210","Dawson's Creek","The O.C.","One Tree Hill","Gossip Girl","Glee","Riverdale","Pretty Little Liars","Veronica Mars","Gilmore Girls","Saved by the Bell","Boy Meets World"]],
      ["Reality & competition", false, ["Survivor","Big Brother","The Amazing Race","American Idol","The Voice","America's Got Talent","Dancing with the Stars","The Bachelor","The Bachelorette","The Real World","Jersey Shore","Keeping Up with the Kardashians","Queer Eye","Shark Tank","The Apprentice","RuPaul's Drag Race","Deadliest Catch","Dirty Jobs","Pawn Stars","MythBusters","Tiger King"]],
      ["Food & home shows", false, ["Top Chef","Hell's Kitchen","MasterChef","Chopped","Diners, Drive-Ins and Dives","Fixer Upper","Property Brothers","House Hunters"]],
      ["Game shows", false, ["Jeopardy!","Wheel of Fortune","The Price Is Right","Family Feud","Who Wants to Be a Millionaire","Deal or No Deal","Press Your Luck","Match Game","Hollywood Squares","Supermarket Sweep"]],
      ["Late night, talk & news", false, ["Saturday Night Live","The Tonight Show","The Late Show","Late Night","The Daily Show","Jimmy Kimmel Live!","The Oprah Winfrey Show","The Ellen DeGeneres Show","The View","Good Morning America","60 Minutes","The Jerry Springer Show","Judge Judy","SportsCenter","In Living Color","The Muppet Show"]],
      ["Pre-1980 classics", false, ["I Love Lucy","The Honeymooners","The Andy Griffith Show","The Dick Van Dyke Show","Bewitched","I Dream of Jeannie","Gilligan's Island","The Brady Bunch","Happy Days","Laverne & Shirley","All in the Family","The Jeffersons","Good Times","Sanford and Son","Three's Company","The Mary Tyler Moore Show","M*A*S*H","Little House on the Prairie","Bonanza","Gunsmoke","The Addams Family","Leave It to Beaver","The Beverly Hillbillies","The Ed Sullivan Show"]],
      ["80s primetime", false, ["Dallas","Dynasty","The A-Team","MacGyver","Moonlighting","The Dukes of Hazzard","Cagney & Lacey","Simon & Simon","Falcon Crest","Knots Landing"]],
    ],
  },
  chefs: {
    label: "Chefs",
    blurb: "100 food personalities",
    groups: [
      ["Food Network famous", false, ["Guy Fieri","Bobby Flay","Rachael Ray","Ina Garten","Giada De Laurentiis","Alton Brown","Emeril Lagasse","Paula Deen","Ree Drummond","Duff Goldman","Buddy Valastro","Anne Burrell","Michael Symon","Ted Allen","Aarón Sánchez","Geoffrey Zakarian","Alex Guarnaschelli","Robert Irvine","Sandra Lee","Valerie Bertinelli"]],
      ["Competition TV & judges", false, ["Gordon Ramsay","Tom Colicchio","Padma Lakshmi","Gail Simmons","Joe Bastianich","Graham Elliot","Curtis Stone","Marcus Samuelsson","Carla Hall","Richard Blais","Stephanie Izard","Kristen Kish","Christina Tosi"]],
      ["Fine dining titans", false, ["Thomas Keller","Daniel Boulud","Jean-Georges Vongerichten","Éric Ripert","David Chang","René Redzepi","Ferran Adrià","Massimo Bottura","Heston Blumenthal","Alain Ducasse","Joël Robuchon","Grant Achatz","Nobu Matsuhisa","Wolfgang Puck","Jiro Ono","Dominique Crenn","Alice Waters","Mario Batali","Marco Pierre White"]],
      ["Culinary legends", false, ["Julia Child","Auguste Escoffier","Marie-Antoine Carême","James Beard","Jacques Pépin","Paul Bocuse","Edna Lewis","Leah Chase","Graham Kerr","Marcella Hazan","Betty Crocker","Colonel Sanders","Chef Boyardee","Martha Stewart"]],
      ["Cookbook authors & home cooks", false, ["Nigella Lawson","Yotam Ottolenghi","Samin Nosrat","Deb Perelman","Alison Roman","Claire Saffitz","Sohla El-Waylly","J. Kenji López-Alt","Jamie Oliver","Rick Bayless","Ming Tsai","Lidia Bastianich","Mary Berry","Paul Hollywood"]],
      ["Internet & viral food creators", false, ["Binging with Babish","Joshua Weissman","Nick DiGiovanni","Keith Lee","Salt Bae","CZN Burak","Uncle Roger","Matty Matheson","Mark Wiens","Amaury Guichon","Rosanna Pansino","Tabitha Brown","Dylan Hollis"]],
      ["Critics, hosts & food travel", false, ["Anthony Bourdain","Andrew Zimmern","Ruth Reichl","Jonathan Gold","Phil Rosenthal","Adam Richman","Stanley Tucci"]],
    ],
  },
  tahoe: {
    label: "South Shore",
    blurb: "150 South Lake & Stateline",
    groups: [
      ["The lake & big landmarks", false, ["Lake Tahoe","Emerald Bay","Vikingsholm","Fannette Island","Eagle Falls","Cave Rock","Zephyr Cove","Heavenly Village","Heavenly Gondola","Tallac Historic Site","Taylor Creek","Valhalla","Camp Richardson","D.L. Bliss State Park","Balancing Rock","Tahoe Keys"]],
      ["Beaches & marinas", false, ["Pope Beach","Baldwin Beach","Kiva Beach","Nevada Beach","Round Hill Pines","El Dorado Beach","Regan Beach","Lakeside Beach","Connolley Beach","Ski Run Marina","Timber Cove Pier","Tahoe Keys Marina","Zephyr Cove Marina","MS Dixie II"]],
      ["Trails, peaks & wilderness", false, ["Mt. Tallac","Desolation Wilderness","Fallen Leaf Lake","Echo Lake","Angora Lakes","Cascade Falls","Rubicon Trail","Tahoe Rim Trail","Pacific Crest Trail","Van Sickle Bi-State Park","Maggies Peaks","Lam Watah Trail","Corral Trail","Powerline Trail","Echo Summit","Luther Pass","Spooner Summit","Freel Peak"]],
      ["Skiing & winter", false, ["Heavenly Mountain Resort","Kirkwood","Sierra-at-Tahoe","Gunbarrel","Mott Canyon","Sky Express","Tamarack Lodge","East Peak Lodge","Stagecoach Express","Boulder Lodge","California Lodge","Unbuckle","Adventure Mountain","Hansen's Resort","Snowshoeing","Snowmobiling","Powder day","Chains required"]],
      ["Stateline & the casinos", false, ["Stateline","Harrah's Lake Tahoe","Harveys","Caesars Republic","Bally's Lake Tahoe","Golden Nugget Lake Tahoe","Tahoe Blue Event Center","Lake Tahoe Outdoor Arena","Edgewood Tahoe","American Century Championship","Sage Room","Friday's Station","Wolf by Vanderpump","Kingsbury Grade","Round Hill","The state line"]],
      ["Local eats & drinks", false, ["Riva Grill","Wet Woody","Base Camp Pizza","Himmel Haus","McP's Taphouse","Red Hut Cafe","Heidi's Pancake House","Bert's Cafe","Cold Water Brewery","South Lake Brewing","Lake Tahoe AleWorX","Sidellis","Freshies","Sprouts Cafe","Blue Angel Cafe","Getaway Cafe","Artemis Lakefront Cafe","Nephele's","Scusa!","Lake Tahoe Pizza Company","Beacon Bar & Grill","Rum Runner","The Naked Fish","Azul Latin Kitchen"]],
      ["Roads & neighborhoods", false, ["Highway 50","Highway 89","The Y","Ski Run Boulevard","Lake Tahoe Boulevard","Pioneer Trail","Emerald Bay Road","Al Tahoe","Bijou","Meyers","Sierra Tract","Montgomery Estates","Christmas Valley","Gardner Mountain","Daggett Pass","Lake Tahoe Airport"]],
      ["Wildlife & nature", false, ["Black bear","Bear box","Chipmunk","Osprey","Bald eagle","Kokanee salmon","Lahontan cutthroat","Mackinaw","Jeffrey pine","Sugar pine","Manzanita","Tahoe blue","Snowpack","Alpine lake"]],
      ["Local life & lore", false, ["Tahoe Tessie","Washoe Tribe","Barton Memorial Hospital","Lake Tahoe Community College","Bijou Community Park","Lakeview Commons","Lake Tahoe Golf Course","Raley's","Grocery Outlet","Fourth of July fireworks","South Lake Tahoe Ice Arena","Angora Fire","Caldor Fire","Locals' discount"]],
    ],
  },
  casino: {
    label: "Casinos",
    blurb: "200 gambling terms",
    groups: [
      ["Table games", false, ["Blackjack","Roulette","Craps","Baccarat","Pai Gow Poker","Three Card Poker","Caribbean Stud","Let It Ride","Casino War","Big Six Wheel","Sic Bo","Keno","Bingo","Mini-baccarat"]],
      ["Blackjack talk", false, ["Hit","Stand","Double down","Split the pair","Insurance","Bust","Push","Soft 17","Surrender","Counting cards","Basic strategy","Twenty-one"]],
      ["Craps", false, ["Come out roll","Pass line","Don't pass","Snake eyes","Boxcars","Seven out","Natural","The point","Hard eight","Field bet","Come bet","Odds bet","Shooter","Stickman","Yo-leven","Blowing on the dice"]],
      ["Roulette", false, ["Red or black","Odd or even","Straight up","Split bet","Double zero","American roulette","European roulette","Croupier","Roulette wheel","Inside bet","Outside bet","No more bets"]],
      ["Poker games & hands", false, ["Texas Hold'em","Omaha","Seven-card stud","Royal flush","Straight flush","Four of a kind","Full house","Flush","Straight","Three of a kind","Two pair","Pocket aces","Big slick","The nuts","The flop","The turn","The river","Community cards","Bad beat"]],
      ["Poker play & slang", false, ["All in","Bluff","Check","Raise","Call","Fold","Ante","Big blind","Small blind","Tell","On tilt","The rake","Chip leader","Heads up","Final table","Dealer button","Slow roll","Cash game","Poker face"]],
      ["Slots & video", false, ["Slot machine","One-armed bandit","Jackpot","Progressive jackpot","Megabucks","Payline","The reels","Cherries","Triple sevens","Wild symbol","Free spins","Bonus round","Penny slot","Video poker","Deuces Wild","Jacks or Better","Loose slot","Ticket in, ticket out"]],
      ["Sportsbook & racing", false, ["Sportsbook","Point spread","Moneyline","Over/under","Parlay","Prop bet","Futures bet","The vig","The juice","Bookmaker","Live betting","Trifecta","Exacta","Daily double","Photo finish","The underdog","The favorite","Cover the spread"]],
      ["The casino floor", false, ["Casino chips","The dealer","Pit boss","The cage","Comped room","Player's card","High roller","The whale","Eye in the sky","Surveillance","Cut card","Minimum bet","Table limit","Buy-in","Cocktail waitress","Free drinks","Casino buffet","No clocks","Casino carpet","The felt"]],
      ["Vegas", false, ["The Strip","Bellagio","Caesars Palace","The Venetian","MGM Grand","The Mirage","Luxor","Excalibur","New York-New York","Mandalay Bay","Wynn","Aria","The Cosmopolitan","Paris Las Vegas","Planet Hollywood","Treasure Island","Circus Circus","Flamingo","Fremont Street","Bellagio fountains","The Tropicana","What happens in Vegas"]],
      ["Beyond Vegas", false, ["Atlantic City","The Borgata","Taj Mahal","The Boardwalk","Monte Carlo","Macau","Venetian Macao","Reno","Foxwoods","Mohegan Sun","Marina Bay Sands","Riverboat casino","Tribal casino","Cruise ship casino"]],
      ["Luck & lore", false, ["Beginner's luck","Hot streak","Cold streak","House edge","The house always wins","Break the bank","Cash out","Chasing losses","Card shark","High stakes","Double or nothing","Bet the farm","Lady Luck","Rabbit's foot","Lucky charm","Beat the odds"]],
    ],
  },
  colleges: {
    label: "Colleges",
    blurb: "150 schools & mascots",
    groups: [
      ["Southeast powers", false, ["Alabama Crimson Tide","Auburn Tigers","Georgia Bulldogs","Florida Gators","LSU Tigers","Tennessee Volunteers","Kentucky Wildcats","South Carolina Gamecocks","Ole Miss Rebels","Mississippi State Bulldogs","Arkansas Razorbacks","Vanderbilt Commodores","Clemson Tigers","Florida State Seminoles","Miami Hurricanes","Georgia Tech Yellow Jackets","Louisville Cardinals","Tulane Green Wave","Appalachian State Mountaineers","Southern Miss Golden Eagles"]],
      ["Midwest & Big Ten country", false, ["Michigan Wolverines","Ohio State Buckeyes","Michigan State Spartans","Penn State Nittany Lions","Wisconsin Badgers","Iowa Hawkeyes","Minnesota Golden Gophers","Illinois Fighting Illini","Indiana Hoosiers","Purdue Boilermakers","Nebraska Cornhuskers","Northwestern Wildcats","Missouri Tigers","Iowa State Cyclones","Cincinnati Bearcats","Notre Dame Fighting Irish","Ohio Bobcats","Toledo Rockets","Western Michigan Broncos","Central Michigan Chippewas"]],
      ["Atlantic Coast & Northeast", false, ["Duke Blue Devils","North Carolina Tar Heels","NC State Wolfpack","Wake Forest Demon Deacons","Virginia Cavaliers","Virginia Tech Hokies","Maryland Terrapins","Rutgers Scarlet Knights","Syracuse Orange","Pittsburgh Panthers","Boston College Eagles","West Virginia Mountaineers","East Carolina Pirates","James Madison Dukes","Old Dominion Monarchs","Richmond Spiders","Temple Owls","Delaware Blue Hens"]],
      ["Texas & the Plains", false, ["Texas Longhorns","Texas A&M Aggies","Texas Tech Red Raiders","Baylor Bears","TCU Horned Frogs","Houston Cougars","SMU Mustangs","Rice Owls","Oklahoma Sooners","Oklahoma State Cowboys","Kansas Jayhawks","Kansas State Wildcats","Tulsa Golden Hurricane","North Dakota State Bison","Wichita State Shockers","Creighton Bluejays"]],
      ["West Coast & Mountain", false, ["USC Trojans","UCLA Bruins","Stanford Cardinal","California Golden Bears","Oregon Ducks","Oregon State Beavers","Washington Huskies","Washington State Cougars","Arizona Wildcats","Arizona State Sun Devils","Utah Utes","BYU Cougars","Colorado Buffaloes","Colorado State Rams","Boise State Broncos","San Diego State Aztecs","UNLV Rebels","Nevada Wolf Pack"]],
      ["Basketball schools", false, ["Villanova Wildcats","Georgetown Hoyas","UConn Huskies","Marquette Golden Eagles","Butler Bulldogs","Xavier Musketeers","Providence Friars","Seton Hall Pirates","St. John's Red Storm","DePaul Blue Demons","Memphis Tigers","Dayton Flyers","VCU Rams","Gonzaga Bulldogs","Saint Mary's Gaels","Davidson Wildcats","Loyola Chicago Ramblers","George Mason Patriots"]],
      ["Ivy League", false, ["Harvard Crimson","Yale Bulldogs","Princeton Tigers","Dartmouth Big Green","Cornell Big Red","Columbia Lions","Brown Bears","Penn Quakers"]],
      ["Service academies & military", false, ["Army Black Knights","Navy Midshipmen","Air Force Falcons","The Citadel Bulldogs"]],
      ["HBCU programs", false, ["Howard Bison","Florida A&M Rattlers","Grambling State Tigers","Southern Jaguars","Jackson State Tigers","North Carolina A&T Aggies","Hampton Pirates","Texas Southern Tigers"]],
      ["Mid-majors", false, ["Marshall Thundering Herd","Coastal Carolina Chanticleers","Liberty Flames","Buffalo Bulls","Akron Zips","Kent State Golden Flashes","Ball State Cardinals","Northern Illinois Huskies","Miami RedHawks","UMass Minutemen","Fresno State Bulldogs","Hawaii Rainbow Warriors"]],
      ["Great mascot names", false, ["UC Santa Cruz Banana Slugs","Southern Illinois Salukis","Evansville Purple Aces","Presbyterian Blue Hose","Campbell Fighting Camels","Wofford Terriers","Furman Paladins","Saint Louis Billikens"]],
    ],
  },
  econ: {
    label: "Economics",
    blurb: "150 econ terms",
    groups: [
      ["Core concepts", false, ["Supply and demand","Scarcity","Opportunity cost","Marginal utility","Diminishing returns","Economies of scale","Comparative advantage","Elasticity","Equilibrium","Incentive","Externality","Public good","Free rider","Sunk cost","Moral hazard"]],
      ["Macro indicators", false, ["GDP","Inflation","Deflation","Stagflation","Recession","Depression","Unemployment rate","Consumer Price Index","Interest rate","Business cycle","Trade deficit","Purchasing power","Cost of living"]],
      ["Money & banking", false, ["Federal Reserve","Central bank","Monetary policy","Money supply","Quantitative easing","Federal funds rate","Fiat money","Gold standard","Bank run","FDIC","Liquidity","Hyperinflation","Exchange rate"]],
      ["Markets & trade", false, ["Free market","Capitalism","Socialism","Command economy","Mixed economy","Monopoly","Oligopoly","Antitrust","Cartel","OPEC","Tariff","Free trade","Protectionism","Globalization","Outsourcing","Black market"]],
      ["Taxes & government", false, ["Fiscal policy","Progressive tax","Regressive tax","Flat tax","Income tax","Capital gains tax","Tax bracket","Budget deficit","National debt","Stimulus","Austerity","Bailout","Deregulation","Price ceiling","Rent control"]],
      ["Labor & wages", false, ["Labor force","Minimum wage","Living wage","Full employment","Labor union","Collective bargaining","Strike","Human capital","Productivity","Gig economy"]],
      ["Investing & finance", false, ["Stock market","Bull market","Bear market","Bond","Dividend","Mutual fund","Index fund","Hedge fund","Portfolio","Diversification","Compound interest","IPO","Short selling","Market crash","Venture capital","Private equity"]],
      ["Schools of thought", false, ["Keynesian economics","Classical economics","Monetarism","Austrian school","Chicago school","Marxism","Supply-side economics","Behavioral economics"]],
      ["Famous economists", false, ["Adam Smith","Karl Marx","John Maynard Keynes","Milton Friedman","David Ricardo","Thomas Malthus","John Stuart Mill","Friedrich Hayek","Joseph Schumpeter","Paul Samuelson","Thorstein Veblen","John Nash","Paul Krugman","Ben Bernanke","Alan Greenspan","Janet Yellen","Jerome Powell","Thomas Piketty","Daniel Kahneman","Richard Thaler"]],
      ["Game theory & behavior", false, ["Game theory","Prisoner's dilemma","Nash equilibrium","Zero-sum game","Tragedy of the commons","Nudge","Loss aversion","Herd behavior","Irrational exuberance","Animal spirits"]],
      ["Famous ideas & moments", false, ["Invisible hand","Laffer curve","Phillips curve","Gini coefficient","Creative destruction","Guns and butter","Laissez-faire","Trickle-down","Dismal science","Bretton Woods","Great Depression","Great Recession","Dot-com bubble","Subprime mortgage"]],
    ],
  },
  duke: {
    label: "Duke Hoops",
    blurb: "100 Blue Devils",
    closed: true,
    groups: [
      ["Laettner era", false, ["Christian Laettner","Bobby Hurley","Grant Hill","Thomas Hill","Brian Davis","Antonio Lang","Cherokee Parks","Alaa Abdelnaby","Phil Henderson","Robert Brickey","Billy McCaffrey","Greg Koubek"]],
      ["Mid-to-late 90s", false, ["Jeff Capel","Chris Collins","Steve Wojciechowski","Trajan Langdon","Ricky Price","Greg Newton","Erik Meek","Roshown McLeod","Chris Carrawell","Nate James","Elton Brand","William Avery","Corey Maggette","Chris Burgess"]],
      ["2001 title era", false, ["Shane Battier","Jason Williams","Carlos Boozer","Mike Dunleavy Jr.","Chris Duhon","Casey Sanders","Nick Horvath","Daniel Ewing","Reggie Love","Sean Dockery","Shavlik Randolph","Shelden Williams","JJ Redick","Lee Melchionni","DeMarcus Nelson"]],
      ["2010 title era", false, ["Josh McRoberts","Greg Paulus","Jon Scheyer","Brian Zoubek","Lance Thomas","Gerald Henderson","Kyle Singler","Nolan Smith","Elliot Williams","Miles Plumlee","Mason Plumlee","Andre Dawkins","Ryan Kelly","Seth Curry"]],
      ["2015 title era", false, ["Quinn Cook","Rasheed Sulaimon","Amile Jefferson","Jabari Parker","Rodney Hood","Matt Jones","Justise Winslow","Tyus Jones","Jahlil Okafor","Grayson Allen","Marshall Plumlee","Brandon Ingram","Luke Kennard","Jayson Tatum","Harry Giles","Frank Jackson"]],
      ["Late Coach K", false, ["Marques Bolden","Marvin Bagley III","Wendell Carter Jr.","Gary Trent Jr.","Trevon Duval","Zion Williamson","RJ Barrett","Cam Reddish","Tre Jones","Jack White","Vernon Carey Jr.","Cassius Stanley","Matthew Hurt"]],
      ["Scheyer era", false, ["Wendell Moore Jr.","Jeremy Roach","Paolo Banchero","Mark Williams","AJ Griffin","Trevor Keels","Kyle Filipowski","Dereck Lively II","Tyrese Proctor","Mark Mitchell","Jared McCain","Cooper Flagg","Kon Knueppel","Khaman Maluach","Sion James","Cameron Boozer"]],
    ],
  },
};

/* ------------------------------------------------------------------ */
/*  HELPERS                                                            */
/* ------------------------------------------------------------------ */
// Accepts an array of deck keys. Order follows DECKS so a given selection always
// pools in the same order regardless of what order the user tapped the tiles.
function flattenDeck(keys) {
  const out = [];
  const taken = new Set();
  const want = new Set(keys);
  Object.keys(DECKS).forEach((k) => {
    if (!want.has(k)) return;
    const d = DECKS[k];
    if (!d) return;
    d.groups.forEach(([group, alcoholic, words]) => {
      words.forEach((text) => {
        // A word can legitimately live in two decks (e.g. "Ratatouille" is a dish
        // and a movie). Pooled play must not deal it twice.
        if (taken.has(text)) return;
        taken.add(text);
        out.push({ text, category: d.label, group, alcoholic, source: "core" });
      });
    });
  });
  return out;
}

// "Beverages", "Beverages + Food", "4 categories", "Everything"
function labelFor(keys) {
  if (keys.length === 0) return "Nothing";
  if (keys.length === Object.keys(DECKS).length) return "Everything";
  if (keys.length === 1) return DECKS[keys[0]].label;
  if (keys.length === 2) return `${DECKS[keys[0]].label} + ${DECKS[keys[1]].label}`;
  return `${keys.length} categories`;
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* Persistence.
   The Claude-artifact build used window.storage, which only exists inside
   Claude. On the open web we use localStorage. Both are wrapped in try/catch
   and keyed with a prefix, so the game still runs (it just forgets) if storage
   is unavailable — Safari private mode, disabled cookies, etc. */
const STORE_PREFIX = "pwg:";

async function storeGet(key) {
  try {
    const raw = window.localStorage.getItem(STORE_PREFIX + key);
    return raw == null ? null : JSON.parse(raw);
  } catch (e) {
    return null;
  }
}
async function storeSet(key, value) {
  try {
    window.localStorage.setItem(STORE_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    /* storage unavailable — game still works, just forgets */
  }
}

/* ------------------------------------------------------------------ */
/*  AUTO-FITTING WORD                                                  */
/* ------------------------------------------------------------------ */
function FitWord({ text }) {
  const boxRef = useRef(null);
  const spanRef = useRef(null);

  useLayoutEffect(() => {
    const box = boxRef.current;
    const span = spanRef.current;
    if (!box || !span) return;
    let lo = 20;
    let hi = 220;
    let best = 20;
    for (let i = 0; i < 14; i++) {
      const mid = (lo + hi) / 2;
      span.style.fontSize = mid + "px";
      if (span.scrollWidth <= box.clientWidth && span.scrollHeight <= box.clientHeight) {
        best = mid;
        lo = mid;
      } else {
        hi = mid;
      }
    }
    span.style.fontSize = best + "px";
  }, [text]);

  // Each word is its own nowrap inline-block, so lines can only break at spaces —
  // never inside a word and never at a hyphen. That also makes the binary search
  // above honest: an oversized font genuinely overflows instead of being silently
  // rescued by a mid-word break.
  const words = text.split(/\s+/).filter(Boolean);

  return (
    <div ref={boxRef} style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
      <span
        ref={spanRef}
        style={{
          fontFamily: "'Anton', 'Arial Narrow', Impact, sans-serif",
          fontWeight: 400,
          lineHeight: 0.95,
          textAlign: "center",
          letterSpacing: "-0.01em",
          textTransform: "uppercase",
          display: "block",
          width: "100%",
          overflowWrap: "normal",
          wordBreak: "normal",
          hyphens: "none",
        }}
      >
        {words.map((w, i) => (
          <span key={i} style={{ display: "inline-block", whiteSpace: "nowrap" }}>
            {i > 0 ? "\u00A0" : ""}
            {w}
          </span>
        ))}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN                                                               */
/* ------------------------------------------------------------------ */
export default function PartyWordGame() {
  const [screen, setScreen] = useState("setup");
  const [categoryKeys, setCategoryKeys] = useState(["beverages"]);
  const [activeLabel, setActiveLabel] = useState("Beverages");
  const [turnLength, setTurnLength] = useState(60);
  const [familyFriendly, setFamilyFriendly] = useState(false);
  const [soundOn, setSoundOn] = useState(true);

  const [deck, setDeck] = useState([]);
  const [current, setCurrent] = useState(null);
  const [turnWords, setTurnWords] = useState([]);
  const [timeLeft, setTimeLeft] = useState(60);
  const [flash, setFlash] = useState(null);
  const [notice, setNotice] = useState(null);
  const [seenCount, setSeenCount] = useState(0);
  const [quitArmed, setQuitArmed] = useState(false);

  const seenRef = useRef(new Set());
  const deckRef = useRef([]);
  const endRef = useRef(0);
  const audioRef = useRef(null);
  const wakeRef = useRef(null);
  const tickRef = useRef(0);
  const settingsLoaded = useRef(false);

  deckRef.current = deck;

  /* ---------- load persisted state ---------- */
  useEffect(() => {
    (async () => {
      const s = await storeGet("seen-words");
      if (Array.isArray(s)) {
        seenRef.current = new Set(s);
        setSeenCount(s.length);
      }
      const cfg = await storeGet("settings");
      if (cfg) {
        if (cfg.turnLength) setTurnLength(cfg.turnLength);
        if (typeof cfg.familyFriendly === "boolean") setFamilyFriendly(cfg.familyFriendly);
        if (typeof cfg.soundOn === "boolean") setSoundOn(cfg.soundOn);
        // Migrate: older builds stored a single `categoryKey`, and "everything"
        // was a pseudo-category rather than a real deck.
        let keys = null;
        if (Array.isArray(cfg.categoryKeys)) keys = cfg.categoryKeys;
        else if (cfg.categoryKey === "everything") keys = Object.keys(DECKS);
        else if (cfg.categoryKey) keys = [cfg.categoryKey];
        if (keys) {
          // Drop anything that no longer exists so a renamed deck can't strand
          // the user on an empty selection.
          const valid = keys.filter((k) => DECKS[k]);
          if (valid.length) setCategoryKeys(valid);
        }
      }
      settingsLoaded.current = true;
    })();
  }, []);

  useEffect(() => {
    if (!settingsLoaded.current) return;
    storeSet("settings", { turnLength, familyFriendly, soundOn, categoryKeys });
  }, [turnLength, familyFriendly, soundOn, categoryKeys]);

  const toggleCategory = useCallback((key) => {
    setCategoryKeys((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }, []);

  /* ---------- audio ---------- */
  const ensureAudio = useCallback(() => {
    if (!audioRef.current) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) audioRef.current = new AC();
    }
    if (audioRef.current && audioRef.current.state === "suspended") audioRef.current.resume();
  }, []);

  const tone = useCallback(
    (freq, dur, type = "sine", vol = 0.18, slideTo = null) => {
      if (!soundOn) return;
      const ctx = audioRef.current;
      if (!ctx) return;
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, ctx.currentTime);
      if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, ctx.currentTime + dur);
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(vol, ctx.currentTime + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + dur + 0.05);
    },
    [soundOn]
  );

  const sfx = {
    got: () => tone(660, 0.12, "triangle", 0.22, 1200),
    skip: () => tone(220, 0.12, "sine", 0.14, 150),
    tick: () => tone(1400, 0.035, "square", 0.07),
    buzz: () => {
      tone(160, 0.7, "sawtooth", 0.25);
      tone(112, 0.7, "square", 0.18);
    },
  };

  const haptic = (ms) => {
    try {
      if (navigator.vibrate) navigator.vibrate(ms);
    } catch (e) {}
  };

  /* ---------- wake lock ---------- */
  const acquireWake = useCallback(async () => {
    try {
      if ("wakeLock" in navigator) wakeRef.current = await navigator.wakeLock.request("screen");
    } catch (e) {}
  }, []);
  const releaseWake = useCallback(() => {
    try {
      if (wakeRef.current) {
        wakeRef.current.release();
        wakeRef.current = null;
      }
    } catch (e) {}
  }, []);

  /* ---------- start ---------- */
  const startGame = useCallback(() => {
    if (categoryKeys.length === 0) return;
    ensureAudio();
    setNotice(null);
    const label = labelFor(categoryKeys);

    let pool = flattenDeck(categoryKeys);
    if (familyFriendly) pool = pool.filter((w) => !w.alcoholic);
    const unseen = pool.filter((w) => !seenRef.current.has(w.text));

    // Deck exhausted: wipe this selection's memory and start the cycle over.
    if (unseen.length < 12) {
      pool.forEach((w) => seenRef.current.delete(w.text));
      const arr = [...seenRef.current];
      setSeenCount(arr.length);
      storeSet("seen-words", arr);
      setNotice(`You've seen every word in ${label}. Starting fresh.`);
      setDeck(shuffle(pool));
    } else {
      setDeck(shuffle(unseen));
    }

    setActiveLabel(label);
    setScreen("handoff");
  }, [categoryKeys, familyFriendly, ensureAudio]);

  /* ---------- round ---------- */
  const drawNext = useCallback(() => {
    setDeck((d) => {
      if (d.length === 0) {
        setCurrent(null);
        return d;
      }
      setCurrent(d[0]);
      return d.slice(1);
    });
  }, []);

  const beginRound = useCallback(() => {
    ensureAudio();
    acquireWake();
    setQuitArmed(false);
    setTurnWords([]);
    setTimeLeft(turnLength);
    tickRef.current = 0;
    endRef.current = Date.now() + turnLength * 1000;
    drawNext();
    setScreen("round");
  }, [turnLength, drawNext, ensureAudio, acquireWake]);

  const endRound = useCallback(() => {
    sfx.buzz();
    haptic([120, 80, 220]);
    releaseWake();
    setScreen("recap");
    const arr = [...seenRef.current];
    setSeenCount(arr.length);
    storeSet("seen-words", arr);
  }, [releaseWake, sfx]);

  // Bail out mid-round. Words already guessed this turn stay marked seen, but the
  // turn is discarded — no recap, straight back to the menu.
  const quitToMenu = useCallback(() => {
    releaseWake();
    setQuitArmed(false);
    setCurrent(null);
    setTurnWords([]);
    setNotice(null);
    setScreen("setup");
    const arr = [...seenRef.current];
    setSeenCount(arr.length);
    storeSet("seen-words", arr);
  }, [releaseWake]);

  /* timer */
  useEffect(() => {
    if (screen !== "round") return;
    const id = setInterval(() => {
      const remain = Math.max(0, (endRef.current - Date.now()) / 1000);
      setTimeLeft(remain);
      if (remain <= 0) {
        clearInterval(id);
        endRound();
        return;
      }
      const gap = remain <= 5 ? 250 : remain <= 10 ? 500 : remain <= 15 ? 1000 : null;
      if (gap && Date.now() - tickRef.current >= gap) {
        tickRef.current = Date.now();
        sfx.tick();
      }
    }, 50);
    return () => clearInterval(id);
  }, [screen, endRound, sfx]);

  /* quit button re-arms itself so a stray tap doesn't sit primed all round */
  useEffect(() => {
    if (!quitArmed) return;
    const id = setTimeout(() => setQuitArmed(false), 3000);
    return () => clearTimeout(id);
  }, [quitArmed]);

  const gotIt = useCallback(() => {
    if (!current) return;
    seenRef.current.add(current.text);
    setTurnWords((t) => [...t, { text: current.text, got: true }]);
    sfx.got();
    haptic(30);
    setFlash("got");
    setTimeout(() => setFlash(null), 130);
    drawNext();
  }, [current, drawNext, sfx]);

  const skipIt = useCallback(
    (e) => {
      e.stopPropagation();
      if (!current) return;
      setTurnWords((t) => [...t, { text: current.text, got: false }]);
      sfx.skip();
      haptic(15);
      setFlash("skip");
      setTimeout(() => setFlash(null), 130);
      setDeck((d) => [...d, current]);
      drawNext();
    },
    [current, drawNext, sfx]
  );

  const toggleWord = (i) => {
    setTurnWords((t) => {
      const copy = t.slice();
      const w = copy[i];
      copy[i] = { ...w, got: !w.got };
      if (w.got) seenRef.current.delete(w.text);
      else seenRef.current.add(w.text);
      storeSet("seen-words", [...seenRef.current]);
      return copy;
    });
  };

  const resetMemory = async () => {
    seenRef.current = new Set();
    setSeenCount(0);
    await storeSet("seen-words", []);
    setNotice("Word memory cleared.");
  };

  /* ---------- derived ---------- */
  const pct = Math.max(0, Math.min(1, timeLeft / turnLength));
  const urgency = timeLeft <= 10 ? "hot" : timeLeft <= 20 ? "warm" : "cool";
  const barColor = urgency === "hot" ? C.danger : urgency === "warm" ? C.amber : C.magenta;
  const roundBg = urgency === "hot" ? "#3A0A18" : urgency === "warm" ? "#241436" : C.ink;
  const gotCount = turnWords.filter((w) => w.got).length;

  /* ---------- shared styles ---------- */
  const shell = {
    position: "absolute",
    inset: 0,
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    color: C.cream,
    display: "flex",
    flexDirection: "column",
    WebkitTapHighlightColor: "transparent",
    userSelect: "none",
    overflow: "hidden",
  };
  const display = { fontFamily: "'Anton', 'Arial Narrow', Impact, sans-serif", textTransform: "uppercase", letterSpacing: "-0.005em", fontWeight: 400 };

  const styleTag = `
    @import url('https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700&display=swap');
    @keyframes pulseGlow { 0%,100% { opacity: 0 } 50% { opacity: .5 } }
    @keyframes rise { from { transform: translateY(14px); opacity: 0 } to { transform: none; opacity: 1 } }
    .pwg-scroll::-webkit-scrollbar { width: 0 }
    .pwg-btn { transition: transform .12s ease, background .18s ease, border-color .18s ease }
    .pwg-btn:active { transform: scale(.975) }
    .pwg-btn:focus-visible { outline: 3px solid ${C.amber}; outline-offset: 3px }
    @media (prefers-reduced-motion: reduce) { .pwg-btn { transition: none } * { animation: none !important } }
  `;

  /* ================================================================ */
  /*  SETUP                                                            */
  /* ================================================================ */
  if (screen === "setup") {
    const cats = [
      { key: "beverages", label: "Beverages", blurb: DECKS.beverages.blurb },
      { key: "food", label: "Food", blurb: DECKS.food.blurb },
      { key: "movies", label: "Movies", blurb: DECKS.movies.blurb },
      { key: "tv", label: "TV Shows", blurb: DECKS.tv.blurb },
      { key: "chefs", label: "Chefs", blurb: DECKS.chefs.blurb },
      { key: "tahoe", label: "South Shore", blurb: DECKS.tahoe.blurb },
      { key: "casino", label: "Casinos", blurb: DECKS.casino.blurb },
      { key: "colleges", label: "Colleges", blurb: DECKS.colleges.blurb },
      { key: "econ", label: "Economics", blurb: DECKS.econ.blurb },
      { key: "duke", label: "Duke Hoops", blurb: DECKS.duke.blurb },
    ];
    // Two-across grid; if the count is odd, the last tile spans full width.
    const orphan = cats.length % 2 === 1 ? cats[cats.length - 1] : null;
    const gridCats = orphan ? cats.slice(0, -1) : cats;
    const allOn = categoryKeys.length === cats.length;
    // Reflects the family-friendly filter, so the number matches what will be dealt.
    const selectionCount = flattenDeck(categoryKeys).filter((w) => !familyFriendly || !w.alcoholic).length;
    const catTile = (c, wide) => {
      const on = categoryKeys.includes(c.key);
      return (
        <button
          key={c.key}
          className="pwg-btn"
          onClick={() => toggleCategory(c.key)}
          role="checkbox"
          aria-checked={on}
          style={{
            position: "relative",
            textAlign: "left",
            padding: "16px 34px 16px 14px",
            borderRadius: 16,
            cursor: "pointer",
            border: `2px solid ${on ? C.magenta : "rgba(255,244,230,0.14)"}`,
            background: on ? "rgba(255,61,127,0.14)" : "rgba(255,244,230,0.04)",
            color: C.cream,
            width: wide ? "100%" : undefined,
          }}
        >
          <div style={{ ...display, fontSize: 22, lineHeight: 1 }}>{c.label}</div>
          <div style={{ fontSize: 12, color: C.dim, marginTop: 5 }}>{c.blurb}</div>
          {/* Checkmark, not just a border tint — with several tiles lit at once the
              border alone is hard to read at a glance. */}
          <div
            style={{
              position: "absolute",
              top: 12,
              right: 12,
              width: 19,
              height: 19,
              borderRadius: 999,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              lineHeight: 1,
              background: on ? C.magenta : "transparent",
              border: `2px solid ${on ? C.magenta : "rgba(255,244,230,0.2)"}`,
              color: on ? C.ink : "transparent",
            }}
          >
            ✓
          </div>
        </button>
      );
    };
    return (
      <div style={{ ...shell, background: `radial-gradient(120% 80% at 50% -10%, ${C.plum} 0%, ${C.ink} 60%)` }}>
        <style>{styleTag}</style>
        <div className="pwg-scroll" style={{ flex: 1, overflowY: "auto", padding: "28px 20px 32px" }}>
          <div style={{ maxWidth: 520, margin: "0 auto" }}>
            <div style={{ ...display, fontSize: 13, letterSpacing: "0.22em", color: C.magenta, marginBottom: 6 }}>Pass the phone</div>
            <h1 style={{ ...display, fontSize: 54, lineHeight: 0.9, margin: "0 0 6px" }}>
              Say it<br />
              <span style={{ color: C.amber }}>without</span> saying it
            </h1>
            <p style={{ color: C.dim, fontSize: 15, margin: "0 0 26px", lineHeight: 1.45 }}>
              One word on screen. Get your friends to guess it before the buzzer.
            </p>

            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10, gap: 10 }}>
              <div style={{ ...display, fontSize: 12, letterSpacing: "0.18em", color: C.dimmer }}>
                Categories
              </div>
              <button
                className="pwg-btn"
                onClick={() => setCategoryKeys(allOn ? [] : cats.map((c) => c.key))}
                style={{
                  ...display,
                  fontSize: 12,
                  letterSpacing: "0.12em",
                  padding: "5px 12px",
                  borderRadius: 999,
                  cursor: "pointer",
                  background: "transparent",
                  border: `1px solid rgba(255,244,230,0.2)`,
                  color: C.dim,
                  whiteSpace: "nowrap",
                }}
              >
                {allOn ? "Clear all" : "Select all"}
              </button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
              {gridCats.map((c) => catTile(c, false))}
            </div>
            {orphan && catTile(orphan, true)}
            <div style={{ fontSize: 12, color: selectionCount ? C.dim : C.danger, marginTop: 10, minHeight: 17 }}>
              {selectionCount
                ? `${labelFor(categoryKeys)} — ${selectionCount.toLocaleString()} words`
                : "Pick at least one category to play."}
            </div>

            <div style={{ ...display, fontSize: 12, letterSpacing: "0.18em", color: C.dimmer, margin: "22px 0 10px" }}>Turn length</div>
            <div style={{ display: "flex", gap: 8 }}>
              {[45, 60, 90].map((t) => {
                const on = turnLength === t;
                return (
                  <button
                    key={t}
                    className="pwg-btn"
                    onClick={() => setTurnLength(t)}
                    style={{
                      flex: 1,
                      padding: "14px 0",
                      borderRadius: 14,
                      cursor: "pointer",
                      border: `2px solid ${on ? C.amber : "rgba(255,244,230,0.14)"}`,
                      background: on ? "rgba(255,193,69,0.16)" : "rgba(255,244,230,0.04)",
                      color: on ? C.amber : C.cream,
                      ...display,
                      fontSize: 20,
                    }}
                  >
                    {t}s
                  </button>
                );
              })}
            </div>

            <div style={{ marginTop: 22, borderTop: "1px solid rgba(255,244,230,0.1)" }}>
              <Toggle label="Family friendly" sub="Hides alcohol words" on={familyFriendly} set={setFamilyFriendly} />
              <Toggle label="Sound" sub="Ticks and buzzer" on={soundOn} set={setSoundOn} />
            </div>

            <div style={{ marginTop: 18, fontSize: 12.5, color: C.dimmer, lineHeight: 1.5 }}>
              {seenCount > 0 ? (
                <>
                  {seenCount} word{seenCount === 1 ? "" : "s"} retired so they don't come back.{" "}
                  <button
                    onClick={resetMemory}
                    style={{ background: "none", border: "none", color: C.magenta, cursor: "pointer", padding: 0, font: "inherit", textDecoration: "underline" }}
                  >
                    Bring them back
                  </button>
                </>
              ) : (
                "Guessed words retire permanently, so repeats stay rare."
              )}
            </div>

            {notice && <div style={{ marginTop: 14, color: C.amber, fontSize: 14 }}>{notice}</div>}
          </div>
        </div>

        <div style={{ padding: "0 20px calc(20px + env(safe-area-inset-bottom))" }}>
          <button
            className="pwg-btn"
            onClick={startGame}
            disabled={selectionCount === 0}
            style={{
              width: "100%",
              maxWidth: 520,
              margin: "0 auto",
              display: "block",
              padding: "20px 0",
              borderRadius: 18,
              border: "none",
              cursor: selectionCount === 0 ? "not-allowed" : "pointer",
              background: selectionCount === 0 ? "rgba(255,244,230,0.12)" : C.magenta,
              color: selectionCount === 0 ? C.dimmer : "#fff",
              ...display,
              fontSize: 26,
              boxShadow: selectionCount === 0 ? "none" : "0 10px 30px rgba(255,61,127,0.3)",
            }}
          >
            Start
          </button>
        </div>
      </div>
    );
  }

  /* ================================================================ */
  /*  HANDOFF                                                          */
  /* ================================================================ */
  if (screen === "handoff") {
    return (
      <button
        onClick={beginRound}
        style={{
          ...shell,
          border: "none",
          cursor: "pointer",
          alignItems: "center",
          justifyContent: "center",
          background: `radial-gradient(100% 70% at 50% 40%, ${C.plum} 0%, ${C.ink} 70%)`,
          padding: 24,
        }}
      >
        <style>{styleTag}</style>
        <div style={{ animation: "rise .35s ease", textAlign: "center" }}>
          <div style={{ ...display, fontSize: 12, letterSpacing: "0.24em", color: C.magenta, marginBottom: 14 }}>{activeLabel}</div>
          <div style={{ ...display, fontSize: 46, lineHeight: 0.95, marginBottom: 18 }}>
            Pass the
            <br />
            phone
          </div>
          <div style={{ fontSize: 16, color: C.dim }}>Tap anywhere when you're ready</div>
        </div>
        <div style={{ position: "absolute", bottom: "calc(26px + env(safe-area-inset-bottom))", fontSize: 12.5, color: C.dimmer }}>
          {turnLength}s · {deck.length} words left
        </div>
      </button>
    );
  }

  /* ================================================================ */
  /*  ROUND                                                            */
  /* ================================================================ */
  if (screen === "round") {
    return (
      <div style={{ ...shell, background: roundBg, transition: "background .5s ease" }}>
        <style>{styleTag}</style>

        {urgency === "hot" && (
          <div style={{ position: "absolute", inset: 0, background: `radial-gradient(80% 60% at 50% 50%, ${C.danger} 0%, transparent 70%)`, animation: "pulseGlow 1s infinite", pointerEvents: "none" }} />
        )}

        <div style={{ height: 10, background: "rgba(255,244,230,0.1)", flexShrink: 0 }}>
          <div style={{ height: "100%", width: `${pct * 100}%`, background: barColor, transition: "width .1s linear, background .4s ease" }} />
        </div>

        <button
          onClick={gotIt}
          style={{
            flex: 1,
            border: "none",
            background: "transparent",
            color: C.cream,
            cursor: "pointer",
            padding: "12px 20px 4px",
            display: "flex",
            flexDirection: "column",
            minHeight: 0,
          }}
        >
          {/* Sits inside the tap target so it doesn't carve a dead strip out of the
              screen. Fixed height either way, so FitWord's box doesn't jump between
              words that have a group and words that don't. */}
          <div
            style={{
              ...display,
              fontSize: 11,
              letterSpacing: "0.16em",
              color: C.dimmer,
              height: 16,
              lineHeight: "16px",
              width: "100%",
              textAlign: "center",
              overflow: "hidden",
              whiteSpace: "nowrap",
              textOverflow: "ellipsis",
              flexShrink: 0,
            }}
          >
            {current ? (
              <>
                <span style={{ color: C.dim }}>{current.category}</span>
                {current.group ? ` · ${current.group}` : ""}
              </>
            ) : (
              ""
            )}
          </div>
          <div style={{ flex: 1, minHeight: 0, width: "100%" }}>
            {current ? <FitWord text={current.text} /> : <div style={{ ...display, fontSize: 28, color: C.dim, textAlign: "center", paddingTop: 40 }}>Out of words</div>}
          </div>
          <div style={{ ...display, fontSize: 12, letterSpacing: "0.2em", color: C.dimmer, padding: "10px 0 2px" }}>Tap when they get it</div>
        </button>

        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 20px calc(18px + env(safe-area-inset-bottom))", flexShrink: 0 }}>
          <div style={{ ...display, fontSize: 26, color: C.mint, minWidth: 60 }}>{gotCount}</div>
          <button
            className="pwg-btn"
            onClick={skipIt}
            style={{
              padding: "12px 30px",
              borderRadius: 999,
              cursor: "pointer",
              background: "transparent",
              border: `2px solid rgba(255,244,230,0.28)`,
              color: C.dim,
              ...display,
              fontSize: 17,
              letterSpacing: "0.06em",
            }}
          >
            Skip
          </button>
          <div style={{ minWidth: 60, display: "flex", justifyContent: "flex-end" }}>
            <button
              className="pwg-btn"
              onClick={(e) => {
                e.stopPropagation();
                if (quitArmed) quitToMenu();
                else setQuitArmed(true);
              }}
              aria-label={quitArmed ? "Confirm end game" : "End game"}
              style={{
                padding: "7px 13px",
                borderRadius: 999,
                cursor: "pointer",
                background: quitArmed ? "rgba(217,16,54,0.22)" : "transparent",
                border: `1px solid ${quitArmed ? C.danger : "rgba(255,244,230,0.2)"}`,
                color: quitArmed ? C.cream : C.dimmer,
                ...display,
                fontSize: 12,
                letterSpacing: "0.1em",
                whiteSpace: "nowrap",
              }}
            >
              {quitArmed ? "Sure?" : "End"}
            </button>
          </div>
        </div>

        {flash && (
          <div
            style={{
              position: "absolute",
              inset: 0,
              pointerEvents: "none",
              background: flash === "got" ? C.mint : "rgba(255,244,230,0.14)",
              opacity: flash === "got" ? 0.32 : 0.18,
            }}
          />
        )}
      </div>
    );
  }

  /* ================================================================ */
  /*  RECAP                                                            */
  /* ================================================================ */
  return (
    <div style={{ ...shell, background: `radial-gradient(120% 70% at 50% 0%, #3A0A18 0%, ${C.ink} 65%)` }}>
      <style>{styleTag}</style>
      <div className="pwg-scroll" style={{ flex: 1, overflowY: "auto", padding: "34px 20px 20px" }}>
        <div style={{ maxWidth: 520, margin: "0 auto", animation: "rise .3s ease" }}>
          <div style={{ ...display, fontSize: 12, letterSpacing: "0.24em", color: C.danger, marginBottom: 10 }}>Time</div>
          <div style={{ ...display, fontSize: 76, lineHeight: 0.85, marginBottom: 4 }}>
            You got <span style={{ color: C.mint }}>{gotCount}</span>
          </div>
          <p style={{ color: C.dim, fontSize: 14, margin: "10px 0 22px" }}>
            {turnWords.length ? "Tap any word to change the call." : "No words this turn — brutal."}
          </p>

          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {turnWords.map((w, i) => (
              <button
                key={i}
                className="pwg-btn"
                onClick={() => toggleWord(i)}
                style={{
                  textAlign: "left",
                  padding: "13px 16px",
                  borderRadius: 13,
                  cursor: "pointer",
                  border: `2px solid ${w.got ? "rgba(61,220,151,0.4)" : "rgba(255,244,230,0.12)"}`,
                  background: w.got ? "rgba(61,220,151,0.1)" : "rgba(255,244,230,0.03)",
                  color: w.got ? C.cream : C.dimmer,
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                }}
              >
                <span style={{ ...display, fontSize: 15, color: w.got ? C.mint : C.dimmer, width: 18 }}>{w.got ? "✓" : "—"}</span>
                <span style={{ ...display, fontSize: 21, textDecoration: w.got ? "none" : "line-through" }}>{w.text}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ padding: "0 20px calc(20px + env(safe-area-inset-bottom))", display: "flex", gap: 10, maxWidth: 520, margin: "0 auto", width: "100%", boxSizing: "border-box" }}>
        <button
          className="pwg-btn"
          onClick={() => setScreen("setup")}
          style={{
            padding: "20px 22px",
            borderRadius: 18,
            cursor: "pointer",
            border: `2px solid rgba(255,244,230,0.2)`,
            background: "transparent",
            color: C.dim,
            ...display,
            fontSize: 20,
          }}
        >
          Menu
        </button>
        <button
          className="pwg-btn"
          onClick={() => setScreen("handoff")}
          style={{
            flex: 1,
            padding: "20px 0",
            borderRadius: 18,
            border: "none",
            cursor: "pointer",
            background: C.magenta,
            color: "#fff",
            ...display,
            fontSize: 24,
            boxShadow: "0 10px 30px rgba(255,61,127,0.28)",
          }}
        >
          Next player
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
function Toggle({ label, sub, on, set }) {
  return (
    <button
      className="pwg-btn"
      onClick={() => set(!on)}
      style={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "16px 2px",
        background: "none",
        border: "none",
        borderBottom: "1px solid rgba(255,244,230,0.1)",
        cursor: "pointer",
        color: C.cream,
        textAlign: "left",
      }}
    >
      <span>
        <span style={{ fontFamily: "'Anton', 'Arial Narrow', Impact, sans-serif", textTransform: "uppercase", fontSize: 19 }}>{label}</span>
        <span style={{ display: "block", fontSize: 12, color: C.dimmer, marginTop: 3 }}>{sub}</span>
      </span>
      <span
        style={{
          width: 52,
          height: 30,
          borderRadius: 999,
          background: on ? C.mint : "rgba(255,244,230,0.16)",
          position: "relative",
          flexShrink: 0,
          transition: "background .2s ease",
        }}
      >
        <span
          style={{
            position: "absolute",
            top: 3,
            left: on ? 25 : 3,
            width: 24,
            height: 24,
            borderRadius: "50%",
            background: on ? "#0E2B1E" : C.cream,
            transition: "left .18s ease",
          }}
        />
      </span>
    </button>
  );
}
